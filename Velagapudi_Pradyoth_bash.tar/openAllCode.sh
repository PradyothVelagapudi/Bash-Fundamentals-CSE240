#!/bin/bash

cat *.h
cat *.hpp
cat *.c
cat *.cpp
cat *.cc
