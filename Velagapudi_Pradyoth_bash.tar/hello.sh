#!/bin/bash

#take command line arg for user's first name
name=$1

echo "Hello $name, I am a BASH script!"
